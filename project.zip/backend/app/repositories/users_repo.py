from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.models import Favorite, Order, OrderItem
from app.models.user import User


def get_user_by_id(db: Session, user_id: int) -> User | None:
    return db.query(User).filter(User.id == user_id).first()


def get_user_by_username(db: Session, username: str) -> User | None:
    return db.query(User).filter(User.username == username).first()


def get_user_by_email(db: Session, email: str) -> User | None:
    return db.query(User).filter(User.email == email).first()


def create_user(
    db: Session,
    *,
    first_name: str,
    last_name: str,
    email: str,
    phone: str,
    country: str,
    city: str,
    username: str,
    password_hash: str,
) -> User:
    user = User(
        first_name=first_name,
        last_name=last_name,
        email=email,
        phone=phone,
        country=country,
        city=city,
        username=username,
        password_hash=password_hash,
    )

    db.add(user)
    db.commit()
    db.refresh(user)

    return user


def delete_user(db: Session, user: User) -> None:
    order_ids_subquery = select(Order.id).where(Order.user_id == user.id)

    db.execute(
        delete(Favorite).where(Favorite.user_id == user.id)
    )

    db.execute(
        delete(OrderItem).where(OrderItem.order_id.in_(order_ids_subquery))
    )

    db.execute(
        delete(Order).where(Order.user_id == user.id)
    )

    db.delete(user)
    db.commit()